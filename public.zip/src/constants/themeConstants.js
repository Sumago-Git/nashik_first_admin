export const LIGHT_THEME = "light";
export const DARK_THEME = "dark";